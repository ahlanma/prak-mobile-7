package com.example.karyawanapp

data class ModelKaryawan(
    val employee_id: String,
    val employee_name: String,
    val jabatan: String,
    val tgl_kerja: String,
    val gaji: String
)
